## consulta de ponto de onibus

`[out:json] [timeout:25]; area(id:3919208145) -> .area_0; ( node["highway"="bus_stop"](area.area_0); way["highway"="bus_stop"](area.area_0); relation["highway"="bus_stop"](area.area_0); ); (._;>;); out body;`

##
