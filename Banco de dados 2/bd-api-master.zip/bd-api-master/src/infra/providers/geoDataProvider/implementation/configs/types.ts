import { Node } from "../../../../../domain/entities/node";

export type Received = {
  elements: [Node];
};
