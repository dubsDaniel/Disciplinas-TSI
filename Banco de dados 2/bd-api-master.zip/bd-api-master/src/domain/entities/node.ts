export type Node = {
  type: string;
  id: number;
  lat: number;
  lon: number;
  tags: [Object];
};
