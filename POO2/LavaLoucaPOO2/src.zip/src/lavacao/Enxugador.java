package lavacao;

import java.util.Random;

public class Enxugador implements Runnable {
	private Escorredor escorredor;
	private Random random = new Random();
	private boolean stop = true;
	
	public Enxugador(Escorredor escorredor) {
		this.escorredor = escorredor;
	}
	
	public void done(boolean stop) {
		//while(escorredor.situacaoEscorredor() > 0) {
			
		//}
		this.stop = stop;
	}
	
	@Override
	public void run() {
		while(stop == false) {
			try {
				escorredor.pegarPrato();
				long time = random.nextInt(500);
				Thread.sleep(time);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
