package lavacao;

public class App {

		private static Escorredor escorredor;
		private static Enxugador enxugador;
		private static Lavador lavador;
		private static Thread threadLavador;
		private static Thread threadEnxugador;
		
		static void work() throws InterruptedException {
			escorredor = new Escorredor(10);
			enxugador = new Enxugador(escorredor);
			lavador = new Lavador(escorredor);
			
			threadLavador = new Thread(lavador);
			threadEnxugador = new Thread(enxugador);
			
			lavador.done(false);
			enxugador.done(false);

			threadLavador.start();
			threadEnxugador.start();
			
			Thread.sleep(10000);
			
			
		}
		
		static void stop() throws InterruptedException {
			lavador.done(true);
			threadLavador.join();
			enxugador.done(true);
			threadEnxugador.join();
			/*try {
				
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Lavamento encerrado");
			}
			*/
		}
		
		
		public static void main(String[] args) throws InterruptedException {
			System.out.println("Começando a lavação");
			work();
			System.out.println("Encerrando a lavação");
			stop();
			System.out.println("Lavação encerrada");
	}

}
