package pratos;

public class Prato extends PratoSujo {
	
	public Prato(int serie, double sujeira) {
		setNumeroDeSerie(serie);
		setNivelSujeira(sujeira);
	}
}
