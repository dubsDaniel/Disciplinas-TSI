package pratos;

public class PratoSujo {
	private int numeroDeSerie;
	private double nivelSujeira;
	
	public double getNivelSujeira() {
		return nivelSujeira;
	}
	
	public void setNivelSujeira(double nivelSujeira) {
		this.nivelSujeira = nivelSujeira;
	}
	
	public int getNumeroDeSerie() {
		return numeroDeSerie;
	}
	
	public void setNumeroDeSerie(int numeroDeSerie) {
		this.numeroDeSerie = numeroDeSerie;
	}
}
